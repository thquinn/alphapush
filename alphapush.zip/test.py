import math
import random
import torch
import torch.nn as nn
from mcts import MCTS
from network import NullNet
from pushfight import PFDirection, PFMove, PFPiece, PFState
from test_null_training import NullTrainingNetwork
from training import eval_match

def versus():
    old_net = torch.load('model_270K_v000.pt', weights_only=False).cpu()
    new_net = torch.load('model_270K_v001.pt', weights_only=False).cpu()
    new_net.eval()
    eval_match(old_net, new_net, evals_per_position=2048, verbose=True)

@torch.no_grad()
def versus_human(model_name = '270K_v001', human_plays_white=True, evals_per_position=20000, temperature=0, state=PFState()):
    print(f'Starting human vs. AI game. Human is playing the {'white' if human_plays_white else 'black'} pieces. Loading {model_name}...')
    net = torch.load(f'model_{model_name}.pt', weights_only=False).cpu()
    illegal_move = False
    while state.winner == PFPiece.Empty:
        if not illegal_move:
            print(state)
        human_turn = human_plays_white == state.white_to_move
        if human_turn:
            move_string = input('Enter your move: ')
            move = PFMove.parse(move_string)
            move = move if move else f'"{move_string}"'
            if move not in state.moves:
                if not illegal_move:
                    print(f'Can\'t play {move}. Legal moves are {', '.join(map(str, state.moves))}.')
                illegal_move = True
                continue
            illegal_move = False
            state.move(move)
        else:
            root_output = net.forward(state.to_tensor().unsqueeze(0))
            if root_output is not None:
                root_output = root_output.numpy()[0]
            mcts = MCTS(PFState.copy(state), root_output)
            moves = []
            while not human_turn and state.winner == PFPiece.Empty:
                print(f'{model_name} running {evals_per_position} evals...')
                mcts.run_with_net(net, evals_per_position, advance=False)
                move = mcts.advance_root(temperature=temperature, print_depth=1, top_n=3)
                state.move(move)
                human_turn = human_plays_white == state.white_to_move
                moves.append(move)
            print(f'{model_name} played {', '.join(map(str, moves))}.')
            print()
    print(state)
    print(f'Game over: {'human' if human_plays_white == state.white_to_move else 'AI'} wins!')

def mate_in_three():
    net = torch.load('model_1M_v009.pt', weights_only=False).cpu().eval()

    state = PFState()
    state.move(PFMove.place(5))
    for i in range(9, 16):
        state.move(PFMove.place(i))
    state.move(PFMove.place(18))
    state.move(PFMove.place(25))
    print(state)

    net.eval()
    mcts = MCTS(state, net.forward(state.to_tensor()))
    for j in range(3):
        for i in range(4000): # best so far: 1-2K
            mcts.select_and_expand()
            mcts.receive_network_output(net.forward(mcts.get_current_state_tensor()))
        mcts.advance_root(temperature=0, print_depth=1)
        print(mcts.root.state)

@torch.no_grad()
def debug_state():
    # net = NullNet()
    net = torch.load('model_270K_v000.pt', weights_only=False).cpu().eval()

    # state = PFState()
    # state = PFState.construct('......W..WwwW.............', False, -1, -1) # "standardized" black starting position
    # state = PFState.construct('wWWw.......W..bB.BBb......', True, 2, -1) # win-in-two that NullNet is missing @512, catching @2048. 270Kv0 catches it at 80!
    # state = PFState.construct('.....W.w...bWW.Bw.bB....B.', True, 2, 19) # tricky win-in-three. Null spots it @24K 270Kv0-1 @16K
    # state = PFState.construct('...w.WB..w..Bb....W.WBb...', False, 2, 18) # 270Kv1 fails to save itself even @100K... bug?
    # state = PFState.construct('.........wwWW.BbB..B.W..b.', False, 2, 21) # 270Kv1 fails @2K
    state = PFState.construct('.......W.w.bWB.B...wB.Wb..', False, 2, 22) # 270Kv1 fails @20K

    print(state)
    mcts = None
    for i in range(2000000):
        if i != 0:
            mcts.select_and_expand()
        output = net.forward(state.to_tensor().unsqueeze(0))
        if output is not None:
            output = output.numpy()[0]
        if i == 0:
            mcts = MCTS(state, output)
        else:
            mcts.receive_network_output(output)
    mcts.advance_root(temperature=0, print_depth=1, top_n=999)

if __name__ == '__main__':
    debug_state()